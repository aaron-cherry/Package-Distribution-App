﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Package_Distribution_App
{
    internal class Package
    {
        //Backing fields
        string _packageID;
        string _destinationCity;
        string _destinationState;

        //Properties
        public string PackageID
        {
            get { return _packageID; }
            set { _packageID = value; }
        }
        public string DestinationCity
        {
            get { return _destinationCity; }
            set { 
                _destinationCity = value;
                }

        }
        public string DestinationState
        {
            get { return _destinationState; }
            set { _destinationState = value; }
        }

        //Constructor
        public Package(string packageID, string destinationCity, string destinationState)
        {
            PackageID = packageID;
            DestinationCity = destinationCity;
            DestinationState = destinationState;
        }


    }
}
